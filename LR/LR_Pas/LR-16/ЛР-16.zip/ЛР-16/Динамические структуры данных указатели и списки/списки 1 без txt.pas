﻿program AlfFreq;

type
  PNode = ^Node;
  Node = record 
    word: string; // слово
    count: integer; // кол-во его встреч
    next: PNode; //ссылка на следующи  эл-нт
  end;

var
  s, word: string;
  i: integer;
  head, p, prev, newNode: PNode;
  diff: integer;
//для записи слова и постановки единицы на счетчик
function CreateNode(w: string): PNode;
var n: PNode;
begin
  new(n);
  n^.word := w;
  n^.count := 1;
  n^.next := nil;
  CreateNode := n;
end;
//вставка нового эл-та в список
procedure AddBefore(var head: PNode; prev, n: PNode);
begin
  if prev = nil then //вставка в начало
  begin
    n^.next := head;
    head := n;
  end
  else
  begin
    n^.next := prev^.next; //в середину, конец
    prev^.next := n;
  end;
end;
//добавление слова
procedure AddWord(w: string);
begin
  p := head;
  prev := nil;

  while (p <> nil) and (p^.word < w) do //поиск места в списке
  begin
    prev := p;
    p := p^.next;
  end;

  if (p <> nil) and (p^.word = w) then //проверка, есть ли слово 
    p^.count := p^.count + 1
  else
  begin
    newNode := CreateNode(w);
    AddBefore(head, prev, newNode);
  end;
end;

begin
  head := nil;

  writeln('Введите строку:');
  readln(s);
  word := '';
// разбиваем строки на слова
  for i := 1 to length(s) do // проход по каждому символу
  begin
    if s[i] > ' ' then
      word := word + s[i]
    else
    begin
      if word <> '' then
      begin
        AddWord(word); //добавляем последнее слово
        word := '';
      end;
    end;
  end;

  { последнее слово }
  if word <> '' then
    AddWord(word);

  diff := 0;
  p := head;
  while p <> nil do //подсчет элементов
  begin
    diff := diff + 1;
    p := p^.next;
  end;

  writeln('Количество различных слов: ', diff);
end.