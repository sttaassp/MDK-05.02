﻿program List2;

type
  PNode = ^Node;
  Node = record
    x: integer;
    next: PNode;
  end;

var
  head, p, n: PNode;
  i, a: integer;

begin
  head := nil;

  for i := 1 to 10 do
  begin
    read(a);
    new(n);
    n^.x := a;
    n^.next := head;
    head := n;
  end;

  writeln('Список:');
  p := head;
  while p <> nil do
  begin
    write(p^.x, ' ');
    p := p^.next;
  end;

  writeln;
  writeln('Четные элементы:');

  p := head;
  while p <> nil do
  begin
    if p^.x mod 2 = 0 then
      write(p^.x, ' ');
    p := p^.next;
  end;
end.