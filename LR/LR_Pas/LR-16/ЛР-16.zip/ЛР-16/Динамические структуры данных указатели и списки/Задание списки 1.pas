﻿program AlfFreq;

type
  PNode = ^Node;
  Node = record
    word: string;
    count: integer;
    next: PNode;
  end;

var
  F: text;
  s: string;
  head, p, prev, newNode: PNode;
  diff: integer;

function CreateNode(w: string): PNode;
var n: PNode;
begin
  new(n);
  n^.word := w;
  n^.count := 1;
  n^.next := nil;
  CreateNode := n;
end;

procedure AddBefore(var head: PNode; prev, n: PNode);
begin
  if prev = nil then
  begin
    n^.next := head;
    head := n;
  end
  else
  begin
    n^.next := prev^.next;
    prev^.next := n;
  end;
end;

begin
  head := nil;
  assign(F,'text.txt');
  reset(F);

  while not eof(F) do
  begin
    readln(F,s);
    p := head;
    prev := nil;

    while (p <> nil) and (p^.word < s) do
    begin
      prev := p;
      p := p^.next;
    end;

    if (p <> nil) and (p^.word = s) then
      p^.count := p^.count + 1
    else
    begin
      newNode := CreateNode(s);
      AddBefore(head, prev, newNode);
    end;
  end;

  close(F);

  diff := 0;
  p := head;
  while p <> nil do
  begin
    diff := diff + 1;
    p := p^.next;
  end;

  writeln('Количество различных слов: ', diff);
end.