﻿program List3;

type
  PNode = ^Node;
  Node = record
    x: integer;
    next: PNode;
  end;

var
  head, p, n: PNode;
  i, a: integer;
  min, max: integer;

begin
  head := nil;

  for i := 1 to 10 do
  begin
    read(a);
    new(n);
    n^.x := a;
    n^.next := head;
    head := n;
  end;

  p := head;
  min := p^.x;
  max := p^.x;

  while p <> nil do
  begin
    if p^.x < min then min := p^.x;
    if p^.x > max then max := p^.x;
    p := p^.next;
  end;

  writeln('Минимальный элемент: ', min);
  writeln('Максимальный элемент: ', max);

end.