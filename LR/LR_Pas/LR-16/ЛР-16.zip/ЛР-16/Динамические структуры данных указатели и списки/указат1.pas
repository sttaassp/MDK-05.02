﻿var
  i: integer;
  i_ptr: ^integer;
begin
  i := 2;
  i_ptr := @i;
  writeln('Значение i: ', i);
  writeln('Адрес i: ', i_ptr);
  writeln('Значение по адресу i_ptr: ', i_ptr^);
end.