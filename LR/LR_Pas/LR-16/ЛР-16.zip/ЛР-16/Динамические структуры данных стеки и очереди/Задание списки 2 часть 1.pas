﻿program ReverseFile;

var
  f1, f2: text;
  a: array[1..100] of integer;
  n, i: integer;

begin
  n := 0;

  assign(f1,'input.txt');
  reset(f1);

  while not eof(f1) do
  begin
    n := n + 1;
    read(f1,a[n]);
  end;

  close(f1);

  assign(f2,'output.txt');
  rewrite(f2);

  for i := n downto 1 do
    write(f2, a[i], ' ');

  close(f2);
end.