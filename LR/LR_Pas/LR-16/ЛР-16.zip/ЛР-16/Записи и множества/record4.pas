﻿type
  toy = record
    name: string;
    price: real;
    age: string;
  end;

var
  toys: array[1..100] of toy;
  f: text;
  n, i: integer;
  filename: string;

begin
  filename := 'toys.txt';

  writeln('ВВОД ДАННЫХ ОБ ИГРУШКАХ');
  write('Сколько игрушек добавить? ');
  readln(n);

  Assign(f, filename);
  Rewrite(f);
  
  for i := 1 to n do
  begin
    writeln('Игрушка №', i);
    
    with toys[i] do
    begin
      write('  Название: ');
      readln(name);
      
      write('  Цена (руб.): ');
      readln(price);
      
      write('  Возрастной диапазон: ');
      readln(age);
      
      writeln(f, name);
      writeln(f, price:0:2);
      writeln(f, age);
    end;

    writeln('-----------------------');
  end;
  
  Close(f);
  writeln('Данные сохранены в файл ', filename);
  writeln;

  writeln('ЧТЕНИЕ ДАННЫХ ИЗ ФАЙЛА');

  Assign(f, filename);
  Reset(f);
  
  i := 0;
  while not Eof(f) do
  begin
    i := i + 1;
    
    with toys[i] do
    begin
      readln(f, name);
      readln(f, price);
      readln(f, age);
      
      writeln('Игрушка №', i);
      writeln('  Название: ', name);
      writeln('  Цена: ', price:0:2, ' руб.');
      writeln('  Возраст: ', age);
      writeln('-----------------------');
    end;
  end;
  
  Close(f);
  writeln('Всего прочитано записей: ', i);
end.