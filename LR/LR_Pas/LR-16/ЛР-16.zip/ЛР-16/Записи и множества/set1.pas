﻿var
  n: integer;
  lastDigit: integer;
  lastTwoDigits: integer;

begin
  write('Введите количество лет: ');
  readln(n);
  
  lastDigit := n mod 10;
  lastTwoDigits := n mod 100;
  
  if lastTwoDigits in [11..14] then
    writeln(n, ' лет')
  else
    if lastDigit in [1] then
      writeln(n, ' год')
    else if lastDigit in [2,3,4] then
      writeln(n, ' года')
    else
      writeln(n, ' лет');
end.