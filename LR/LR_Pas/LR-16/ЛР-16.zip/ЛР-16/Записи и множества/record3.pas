﻿type
  toy = record
    name: string[30];    
    price: real;
    age: string[10];
  end;

var
  toys: array[1..100] of toy; 
  toy_item: toy;          
  f: file of toy;             
  n, i: integer;
  filename: string;

begin
  filename := 'toys.dat'; 

  writeln('ВВОД ДАННЫХ ОБ ИГРУШКАХ');
  write('Сколько игрушек добавить? ');
  readln(n);

  Assign(f, filename);
  Rewrite(f);
  
  for i := 1 to n do
  begin
    writeln('Игрушка №', i);
    
    with toys[i] do
    begin
      write('  Название: ');
      readln(name);
      
      write('  Цена (руб.): ');
      readln(price);
      
      write('  Возрастной диапазон: ');
      readln(age);
    end;

    write(f, toys[i]);
    writeln('-----------------------');
  end;
  
  Close(f);
  writeln('Данные сохранены в файл ', filename);
  writeln;

  writeln('ЧТЕНИЕ ДАННЫХ ИЗ ФАЙЛА');

  Assign(f, filename);
  Reset(f);
  
  i := 0;
  while not Eof(f) do
  begin
    i := i + 1;
    Read(f, toys[i]);
    
    with toys[i] do
    begin
      writeln('Игрушка №', i);
      writeln('  Название: ', name);
      writeln('  Цена: ', price:0:2, ' руб.');
      writeln('  Возраст: ', age);
      writeln('-----------------------');
    end;
  end;
  
  Close(f);
  
  writeln('Всего прочитано записей: ', i);
end.