﻿type
  anketa=record
    fio:string;
    birth:string;
    kurs:1..5;
  end;
var s: anketa;
begin
  s.fio:='Иванов Иван Иванович';
  s.birth:='15.03.2004';
  s.kurs:=3;
  Writeln($'Анкетные данные студента:');
  Writeln($'-----------------------');
  Writeln($'Ф.И.О.: {s.fio}');
  Writeln($'Дата рождения: {s.birth}');
  Writeln($'Курс: {s.kurs}');
end.