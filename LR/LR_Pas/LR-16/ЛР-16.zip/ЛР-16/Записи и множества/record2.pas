﻿type
  student = auto class
    fio, birth: string;
    kurs: integer;
  end;
begin
  var students := Arr(
    new student('Иванов Иван', '15.03.2004', 3),
    new student('Петрова Анна', '22.07.2005', 2),
    new student('Сидоров Петр', '10.11.2003', 4)
  ); 
  foreach var s in students do
    Writeln($'{s.fio} | {s.birth} | {s.kurs} курс');
end.