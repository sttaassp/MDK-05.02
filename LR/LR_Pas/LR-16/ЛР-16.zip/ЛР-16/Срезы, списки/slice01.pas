﻿begin
  var N:=ReadInteger('Сколько элементов?');
  var a:=ReadArrReal(N);
  a[::-1].Println;
end.