﻿begin
  var a:=arr(23, 5, 67, 11, 8, 32, 1, 66);
  println('массив:', a);
  var n:=ReadInteger('ввведите число');
  var k:=a.IndexMin;
  a:= a[:k] + arr(n) + a[k:]; 
  print('результат:', a); 
end.