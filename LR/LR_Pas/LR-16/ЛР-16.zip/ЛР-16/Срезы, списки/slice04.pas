﻿begin
  var a:=arr(23, 5, 67, 11, 8, 32, 1, 66);
  println('массив:', a);
  var k:=a.IndexMax;
  a:= a[:k] + a[k+1:]; 
  print('результат:', a)
end.