﻿begin
    var n:=ReadInteger('Сколько элементов');
    var a:=arrrandominteger(n);
    a.Println;
    var slice:=a[1::2];
    Println('срез: ',slice);
    Print('min:', slice.Min);
    
end.