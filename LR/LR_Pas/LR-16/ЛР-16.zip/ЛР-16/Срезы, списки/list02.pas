﻿begin
  var L := ArrRandomInteger(10, 0, 100).ToList;
  Print('список:');
  L.JoinIntoString(' ').Println;
  var maxIndex := L.IndexMax; 
  L.RemoveAt(maxIndex);
  Print('результат: [');
  L.JoinIntoString(', ').Print;
  Println(']');
end.