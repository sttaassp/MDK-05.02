unit Edit;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons,
  MaskEdit;

type

  { TfEdit }

  TfEdit = class(TForm)
    bSave: TBitBtn;
    bCancel: TBitBtn;
    CBNote: TComboBox;
    eName: TEdit;
    LabType: TLabel;
    LabTelephone: TLabel;
    labName: TLabel;
    eTelephone: TMaskEdit;
    procedure CBNoteChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure LabTypeClick(Sender: TObject);
    procedure eTelephoneChange(Sender: TObject);
  private

  public

  end;

var
  fEdit: TfEdit;

implementation

{$R *.lfm}

{ TfEdit }

procedure TfEdit.LabTypeClick(Sender: TObject);
begin

end;

procedure TfEdit.eTelephoneChange(Sender: TObject);
begin

end;

procedure TfEdit.FormShow(Sender: TObject);
begin
  eName.SetFocus;
end;

procedure TfEdit.FormCreate(Sender: TObject);
begin

end;

procedure TfEdit.CBNoteChange(Sender: TObject);
begin
  case CBNote.Text of
    'Мобильный':
      eTelephone.EditMask := '+7!(999) 000-00-00;1;_';
    'Домашний':
      // Например, для городского с кодом города (ХХХ) ХХ-ХХ-ХХ
      eTelephone.EditMask := '+7!(8332) 00-00-00;1;_';
    'Служебный':
      // Например, короткий номер или номер с добавочным
      eTelephone.EditMask := '!00-00;1;_';
    'Соседский':
      // Например, просто 7 цифр
      eTelephone.EditMask := '+7!(999) 000-00-00;1;_';
  else
    eTelephone.EditMask := ''; // Если выбрано что-то иное — убираем маску
  end;
end;

end.

