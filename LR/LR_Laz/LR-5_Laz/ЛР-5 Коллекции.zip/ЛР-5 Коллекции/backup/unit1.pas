unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    bStart: TButton;
    bClear: TButton;
    bExit: TButton;
    bNext: TButton;
    bCheck: TButton;
    bPrev: TButton;
    bRules: TButton;
    cbLevel: TComboBox;
    edAnswer: TEdit;
    Image1: TImage;
    LabName: TLabel;
    mTerms: TMemo;
    procedure bCheckClick(Sender: TObject);
    procedure bClearClick(Sender: TObject);
    procedure bExitClick(Sender: TObject);
    procedure bNextClick(Sender: TObject);
    procedure bPrevClick(Sender: TObject);
    procedure bRulesClick(Sender: TObject);
    procedure bStartClick(Sender: TObject);
    procedure cbLevelChange(Sender: TObject);
    procedure edAnswerChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ShowWord;
    procedure FormDestroy(Sender: TObject);

  private

  public

  end;

var
  Form1: TForm1;
  FullList: TStringList;
  CurrentIndex: integer;

implementation

{$R *.lfm}

{ TForm1 }



procedure TForm1.cbLevelChange(Sender: TObject);
begin

end;

procedure TForm1.edAnswerChange(Sender: TObject);
begin
end;

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  if FullList <> nil then FullList.Free;
end;

procedure TForm1.bClearClick(Sender: TObject);
begin
  mTerms.Lines.Clear;
  edAnswer.Clear;
end;

procedure TForm1.bCheckClick(Sender: TObject);
var
  FullLine, CorrectWord: string;
  p: integer;
begin
  ;if (FullList = nil) or (FullList.Count = 0) then Exit;

  FullLine := FullList.Strings[CurrentIndex];
  p := Pos(':', FullLine);

  if p > 0 then
  begin
    CorrectWord := Trim(Copy(FullLine, p + 1, MaxInt));

    if LowerCase(Trim(edAnswer.Text)) = LowerCase(CorrectWord) then
    begin
      ShowMessage('Верно! Енотик молодец! ');
      if CurrentIndex < FullList.Count - 1 then bNextClick(Sender);
    end
    else
      ShowMessage('Неверно, енотик, проверь еще раз.');
  end
end;

procedure TForm1.bExitClick(Sender: TObject);
begin
  Close;
end;

procedure TForm1.bNextClick(Sender: TObject);
begin
  if (FullList <> nil) and (CurrentIndex < FullList.Count - 1) then
    begin
      Inc(CurrentIndex); // Увеличиваем индекс на 1
      ShowWord;
    end;
end;

procedure TForm1.bPrevClick(Sender: TObject);
begin
  if (FullList <> nil) and (CurrentIndex > 0) then
  begin
    Dec(CurrentIndex); // Уменьшаем индекс на 1
    ShowWord;
  end;
end;

procedure TForm1.bRulesClick(Sender: TObject);
begin
  ShowMessage(
    'Правила тренажёра "IT-Словарь":' + #13#10 +
    '1. Нажмите "Начать игру", чтобы загрузить список терминов.' + #13#10 +
    '2. В поле ввода напишите перевод текущего слова на английский.' + #13#10 +
    '3. Нажмите "Проверить" для подтверждения написания слова.' + #13#10 +
    '4. Используйте кнопки "Назад" и "Далее" для навигации по списку.' + #13#10 +
    '----------------------------------------------------------------' + #13#10 +
    'Уровни сложности:' + #13#10 +
    '- Новичок: обычный порядок слов.' + #13#10 +
    '- Профи: список переворачивается (с конца в начало).'
  );
end;

procedure TForm1.bStartClick(Sender: TObject);
var
  TempList: TStringList;
  i: integer;
begin
  if not FileExists('terms.txt') then
  begin
    ShowMessage('Файл не найден!');
    Exit;
  end;
  if FullList = nil then
    FullList := TStringList.Create
  else
    FullList.Clear;
  FullList.LoadFromFile('terms.txt');
  if cbLevel.ItemIndex = 1 then
  begin
    TempList := TStringList.Create;
    try
      for i := FullList.Count - 1 downto 0 do
        TempList.Add(FullList.Strings[i]);
      FullList.Assign(TempList);
    finally
      TempList.Free;
    end;
  end;
  CurrentIndex := 0;
  ShowWord;
end;

procedure TForm1.ShowWord;
var s: string; p: integer;
begin
  if (FullList <> nil) and (FullList.Count > 0) then
  begin
    s := FullList.Strings[CurrentIndex];
    p := Pos(':', s);
    if p > 0 then
      mTerms.Text := Trim(Copy(s, 1, p - 1))
    else
      mTerms.Text := s;

    edAnswer.Clear;
    edAnswer.SetFocus;
    // Можно вывести в заголовок формы прогресс (1 из 100)
    Caption := 'Слово ' + IntToStr(CurrentIndex + 1) + ' из ' + IntToStr(FullList.Count);
  end;
end;

end.

