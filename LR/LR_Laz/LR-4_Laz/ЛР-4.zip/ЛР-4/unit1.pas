unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Math;

type

  { TCalculator }

  TCalculator = class(TForm)
    btnBack: TButton;
    btn4: TButton;
    btn6: TButton;
    btnMul: TButton;
    btnInvX: TButton;
    btn5: TButton;
    btn1: TButton;
    btn3: TButton;
    btnMinus: TButton;
    btn2: TButton;
    btn0: TButton;
    btnCE: TButton;
    btnDot: TButton;
    btnPlus: TButton;
    btnEqual: TButton;
    btn9: TButton;
    btn8: TButton;
    btn7: TButton;
    btnClear: TButton;
    btnSqrt: TButton;
    btnDiv: TButton;
    btnSqrX: TButton;
    PoleVivoda: TMemo;
    procedure btnCEClick(Sender: TObject);
    procedure NumberClick(Sender: TObject);
    procedure btnBackClick(Sender: TObject);
    procedure btnDotClick(Sender: TObject);
    procedure btnClearClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnSqrXClick(Sender: TObject);
    procedure btnInvXClick(Sender: TObject);
    procedure btnEqualClick(Sender: TObject);
    procedure OperationClick(Sender: TObject);
    procedure btnSqrtClick(Sender: TObject);
    procedure PoleVivodaChange(Sender: TObject);

  private

  public

  end;

var
  Calculator: TCalculator;
  FirstNum: Extended;  // Первое число для операции
  Op: string;        // Знак операции
  IsNewNum: Boolean; // Флаг: начинаем ли ввод нового числа


implementation

{$R *.lfm}

{ TCalculator }

// Обработка цифр с защитой от "Ошибка"
procedure TCalculator.NumberClick(Sender: TObject);
var Digit: string;
begin
  Digit := (Sender as TButton).Caption;
  if IsNewNum or (PoleVivoda.Text = '0') then
  begin
    PoleVivoda.Text := Digit;
    IsNewNum := False;
  end
  else
    PoleVivoda.Text := PoleVivoda.Text + Digit;
end;

// Обработка операций (+ - * /)
procedure TCalculator.OperationClick(Sender: TObject);
begin
  if PoleVivoda.Text <> '' then
  begin
    FirstNum := StrToFloatDef(PoleVivoda.Text, 0);
    Op := (Sender as TButton).Caption;
    IsNewNum := True; // После выбора операции ждем новое число
  end;
end;

// Очищает последнее введенное число
procedure TCalculator.btnCEClick(Sender: TObject);
begin
  PoleVivoda.Clear;
  PoleVivoda.Text:='0';
end;

// Безопасное удаление символа
procedure TCalculator.btnBackClick(Sender: TObject);
begin
  if Length(PoleVivoda.Text) > 1 then
    PoleVivoda.Text := Copy(PoleVivoda.Text, 1, Length(PoleVivoda.Text) - 1)
  else
    PoleVivoda.Text := '0';
end;
// Запрещает ввод нескольких точек
procedure TCalculator.btnDotClick(Sender: TObject);
begin
  if PoleVivoda.Text = '0' then
    PoleVivoda.Text := '0,'
  else if Pos(',', PoleVivoda.Text) = 0 then
    PoleVivoda.Text := PoleVivoda.Text + ',';
end;

// Очищает все окно вывода
procedure TCalculator.btnClearClick(Sender: TObject);
begin
  PoleVivoda.Clear;
  PoleVivoda.Text:='0';
  FirstNum := 0;
  Op := '';
  IsNewNum := False;
end;

// Извлекает корень из числа
procedure TCalculator.btnSqrtClick(Sender: TObject);
var Val: Double;
begin
  Val := StrToFloatDef(PoleVivoda.Text, 0);
  if Val < 0 then
    ShowMessage('Нельзя извлечь корень из отрицательного числа')
  else
    PoleVivoda.Text := FloatToStr(Sqrt(Val));
  IsNewNum := True;
end;

procedure TCalculator.PoleVivodaChange(Sender: TObject);
begin

end;

// Возводит число в квадрат
procedure TCalculator.btnSqrXClick(Sender: TObject);
var Val: Double;
begin
  Val := StrToFloatDef(PoleVivoda.Text, 0);

  try
    Val := Sqr(Val);

    if IsInfinite(Val) or IsNan(Val) then
      raise EOverflow.Create('');

    PoleVivoda.Text := FloatToStr(Val);
  except
    on EOverflow do
    begin
      ShowMessage('Слишком большое число!');
      PoleVivoda.Text := '0';
    end;
  end;
  IsNewNum := True;
end;

// Вычисляет 1 / x
procedure TCalculator.btnInvXClick(Sender: TObject);
var Val: Double;
begin
  Val := StrToFloatDef(PoleVivoda.Text, 0);
  if Val = 0 then
    ShowMessage('Деление на ноль невозможно!')

  else
    PoleVivoda.Text := FloatToStr(1 / Val);
  IsNewNum := True;
end;

// Выполняет вычисление с обработкой ошибок
procedure TCalculator.btnEqualClick(Sender: TObject);
var SecondNum, Result: Extended;
begin
  if Op = '' then Exit;
  SecondNum := StrToFloatDef(PoleVivoda.Text, 0);
  try
    case Op of
      '+': Result := FirstNum + SecondNum;
      '-': Result := FirstNum - SecondNum;
      '*': Result := FirstNum * SecondNum;
      '/':
        begin
          if SecondNum = 0 then
          begin
            ShowMessage('Деление на ноль невозможно!');
            Op := '';
            IsNewNum := True;
            Exit;
          end;
          Result := FirstNum / SecondNum;
        end;
    else
      Exit;
    end;
    PoleVivoda.Text := FloatToStr(Result);
  except
    on EOverflow do
    begin
      ShowMessage('Слишком большое число!');
      PoleVivoda.Text := '0';
    end;
    on Exception do
    begin
      ShowMessage('Ошибка в вычислениях');
    end;
  end;
  IsNewNum := True;
  Op := '';
end;

// Инициализации формы при запуске приложения
procedure TCalculator.FormCreate(Sender: TObject);
begin
  IsNewNum := False;
  Op := '';
end;

end.

