unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin

end;



procedure TForm1.Button1Click(Sender: TObject);
var R,n,d,S:double;
begin
  R:=StrToFloat(Edit1.Text);
  n:=StrToFloat(Edit2.Text);
  d:=2*R;
  S:=(4*sqr(n)*sqr(R))/(sqr(n)+1);
  Edit3.Text := FloatToStrF(d, ffFixed);
  Edit4.Text := FloatToStrF(S, ffFixed, 8, 4)
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  Edit1.Clear;
  Edit2.Clear;
  Edit3.Clear;
  Edit4.Clear;
  Edit1.SetFocus;
end;

procedure TForm1.Label1Click(Sender: TObject);
begin

end;

end.

