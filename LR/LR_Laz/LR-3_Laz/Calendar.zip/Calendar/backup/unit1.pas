unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, LazUTF8, Forms, Controls, Graphics, Dialogs, Calendar, EditBtn,
  StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    btnDate: TButton;
    btnTime: TButton;
    btnNow: TButton;
    btnFormat: TButton;
    btnDecode: TButton;
    btnEncode: TButton;
    btnUTF: TButton;
    Calendar1: TCalendar;
    DateEdit1: TDateEdit;
    lResult: TLabel;
    procedure btnDateClick(Sender: TObject);
    procedure btnDecodeClick(Sender: TObject);
    procedure btnEncodeClick(Sender: TObject);
    procedure btnFormatClick(Sender: TObject);
    procedure btnNowClick(Sender: TObject);
    procedure btnTimeClick(Sender: TObject);
    procedure btnToStringClick(Sender: TObject);
    procedure btnUTFClick(Sender: TObject);
    procedure Calendar1Change(Sender: TObject);
    procedure lResultClick(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.btnDateClick(Sender: TObject);
var s: string;
begin
   case DayOfWeek(DateEdit1.Date) of
   1: s := 'Воскресенье';
   2: s := 'Понедельник';
   3: s := 'Вторник';
   4: s := 'Среда';
   5: s := 'Четверг';
   6: s := 'Пятница';
   7: s := 'Суббота';
   end;
   lResult.Caption := 'Сегодня: ' + DateToStr(Date) + ' (' + s + ')';
end;

procedure TForm1.btnDecodeClick(Sender: TObject);
var   Year, Month, Day: Word;
begin
    DecodeDate(DateEdit1.Date, Year, Month, Day);

  lResult.Caption :=
    'Год: ' + IntToStr(Year) + ' | ' +
    'Месяц: ' + IntToStr(Month) + ' | ' +
    'День: ' + IntToStr(Day);
end;

procedure TForm1.btnEncodeClick(Sender: TObject);
var dt: TDateTime;
begin
  dt := EncodeDate(2025, 12, 31);
  lResult.Caption := 'Созданная дата: ' + DateToStr(dt);
end;

procedure TForm1.btnFormatClick(Sender: TObject);
begin
  lResult.Caption := FormatDateTime('dd.mm.yyyy hh:nn:ss', Now);
end;

procedure TForm1.btnNowClick(Sender: TObject);
begin
  lResult.Caption := 'Дата и время: ' + DateTimeToStr(Now);
end;

procedure TForm1.btnTimeClick(Sender: TObject);
begin
  lResult.Caption := 'Сейчас: ' + TimeToStr(Time);
end;

procedure TForm1.btnToStringClick(Sender: TObject);
var s: string;
begin
  DateTimeToString(s, 'dd.mm.yyyy hh:nn:ss', Now);
  lResult.Caption := s;
end;

procedure TForm1.btnUTFClick(Sender: TObject);
begin
    lResult.Caption := SysToUTF8(FormatDateTime('dd mmmm yyyy', Now));
end;

procedure TForm1.Calendar1Change(Sender: TObject);
begin
   DateEdit1.Date := Calendar1.DateTime;
end;

procedure TForm1.lResultClick(Sender: TObject);
begin

end;

end.

