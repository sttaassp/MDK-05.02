unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Buttons;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitExit: TBitBtn;
    btnCalcul: TButton;
    BtnCLearing: TButton;
    CbMaterial: TComboBox;
    EdHeight: TEdit;
    EdLength: TEdit;
    EdWidth: TEdit;
    Image1: TImage;
    LabClock: TLabel;
    LabCurrentTime: TLabel;
    LabHeight: TLabel;
    LabMaterial: TLabel;
    LabResult: TLabel;
    LabWidth: TLabel;
    labLength: TLabel;
    tmrClock: TTimer;
    procedure BitExitClick(Sender: TObject);
    procedure btnCalculClick(Sender: TObject);
    procedure BtnClearingClick(Sender: TObject);
    procedure CbMaterialChange(Sender: TObject);
    procedure EdWidthChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure LabCurrentTimeClick(Sender: TObject);
    procedure LabResultClick(Sender: TObject);
    procedure tmrClockTimer(Sender: TObject);
  private
    StartTime: TDateTime; // Хранение время старта
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.LabResultClick(Sender: TObject);
begin

end;


procedure TForm1.tmrClockTimer(Sender: TObject);
var Duration: TDateTime;
begin
  Duration := Now - StartTime;
  LabClock.Caption := 'В работе: ' + FormatDateTime('nn:ss', Duration);
  LabCurrentTime.Caption := 'Текущее время: ' + FormatDateTime('hh:nn:ss', Now);
end;

procedure TForm1.CbMaterialChange(Sender: TObject);
begin

end;

procedure TForm1.EdWidthChange(Sender: TObject);
begin

end;

procedure TForm1.btnCalculClick(Sender: TObject);
var a, b, h, V, rho, m: Double;
    Densities: array[0..9] of Double = (7850, 2700, 8960, 19300, 10500, 11340, 2400, 2500, 700, 500);
begin
  if (EdLength.Text = '') or (EdWidth.Text = '') or (EdHeight.Text = '') then
  begin
    ShowMessage('Пу-пу-пу! Поля пустые..Сначала введите размеры!');
    LabResult.Caption := 'Ошибочка...';
    LabResult.Font.Color := clRed;
    EdLength.Text := '';
    EdWidth.Text := '';
    EdHeight.Text := '';
    EdLength.SetFocus;
    Exit;
  end;
  try
    a := StrToFloat(EdLength.Text);
    b := StrToFloat(EdWidth.Text);
    h := StrToFloat(EdHeight.Text);
    if (a <= 0) or (b <= 0) or (h <= 0) then
    begin
      ShowMessage('Пу-пу-пу! Размеры должны быть больше нуля!');
      LabResult.Caption := 'Ошибочка...';
      LabResult.Font.Color := clRed;
      EdLength.Text := '';
      EdWidth.Text := '';
      EdHeight.Text := '';
      EdLength.SetFocus;
      Exit;
    end;
    // Получаем плотность из массива в ComboBox
    rho := Densities[CbMaterial.ItemIndex];
    V:= a * b * h;
    m:= V * rho;
    LabResult.Caption := 'Результат: ' + FloatToStrF(m, ffFixed, 8, 2) + ' кг';
    LabResult.Font.Color := clGreen;

  except
    // Если произошла ошибка при конвертации (буквы вместо цифр)
    on E: EConvertError do
    begin
      ShowMessage('Пу-пу-пу! Пишем только циферки');
      LabResult.Caption := 'Ошибочка...';
      LabResult.Font.Color := clRed;
      EdLength.Text := '';
      EdWidth.Text := '';
      EdHeight.Text := '';
      EdLength.SetFocus
    end;
  end;
end;

procedure TForm1.BtnClearingClick(Sender: TObject);
begin
  EdLength.Text := '';
  EdWidth.Text := '';
  EdHeight.Text := '';
  LabResult.Caption := 'Печатай циферки...';
  LabResult.Font.Color := clDefault;
  EdLength.SetFocus;
end;

procedure TForm1.BitExitClick(Sender: TObject);
begin
  Close;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  StartTime := Now;
  cbMaterial.ItemIndex := 0;
end;

procedure TForm1.LabCurrentTimeClick(Sender: TObject);
begin

end;

end.

