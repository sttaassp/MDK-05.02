unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  MaskEdit, Grids, Menus;
type
  TStudent = record
    TicketNumber: Integer;
    FullName: string[80];
    Group: string[50];
    BirthDate: TDateTime;
    AdmissionYear: Integer;
  end;

type

  { TfMain }

  TfMain = class(TForm)
    edFullName: TEdit;
    edGroup: TEdit;
    LabBirthDate: TLabel;
    LabAdmYear: TLabel;
    LabGroup: TLabel;
    LabFullName: TLabel;
    MainMenu1: TMainMenu;
    meAdmYear: TMaskEdit;
    meBirthDate: TMaskEdit;
    miExportText: TMenuItem;
    miFile: TMenuItem;
    miEdit: TMenuItem;
    miDel: TMenuItem;
    miSort: TMenuItem;
    miSortAsc: TMenuItem;
    miSortDesc: TMenuItem;
    miSearch: TMenuItem;
    miClear: TMenuItem;
    miFileNew: TMenuItem;
    miFileOpen: TMenuItem;
    miFileSave: TMenuItem;
    miFileSaveas: TMenuItem;
    miHelp: TMenuItem;
    miFileExit: TMenuItem;
    miRecord: TMenuItem;
    miAdd: TMenuItem;
    meTicketNum: TMaskEdit;
    LabTicketNum: TLabel;
    odMain: TOpenDialog;
    pnlInput: TPanel;
    sdMain: TSaveDialog;
    sgStudents: TStringGrid;
    procedure FormCreate(Sender: TObject);
    procedure miAddClick(Sender: TObject);
    procedure miClearClick(Sender: TObject);
    procedure miDelClick(Sender: TObject);
    procedure miEditClick(Sender: TObject);
    procedure miExportTextClick(Sender: TObject);
    procedure miFileClick(Sender: TObject);
    procedure miHelpClick(Sender: TObject);
    procedure miFileExitClick(Sender: TObject);
    procedure miFileNewClick(Sender: TObject);
    procedure miFileOpenClick(Sender: TObject);
    procedure ExportToText(FileName: string);
    procedure miFileSaveasClick(Sender: TObject);
    procedure miSearchClick(Sender: TObject);
    procedure miSortAscClick(Sender: TObject);
    procedure miSortDescClick(Sender: TObject);
    procedure sgStudentsSelectCell(Sender: TObject; aCol, aRow: Integer;
      var CanSelect: Boolean);
  private
    tempF: file of TStudent;
    F: file of TStudent;
    sFileName: string;
    procedure RefreshGrid;
    procedure ExportToText;

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.FormCreate(Sender: TObject);
begin
  // Настройка заголовков (уже делали, убедись что есть)
  sgStudents.Cells[0, 0] := '№ билета';
  sgStudents.Cells[1, 0] := 'ФИО';
  sgStudents.Cells[2, 0] := 'Группа';
  sgStudents.Cells[3, 0] := 'Дата рождения';
  sgStudents.Cells[4, 0] := 'Год поступления';
  sgStudents.ColWidths[0] := 80;  // Номер билета
  sgStudents.ColWidths[1] := 300; // ФИО
  sgStudents.ColWidths[2] := 50;  // Группа
  sgStudents.ColWidths[3] := 50; // Дата
  sgStudents.ColWidths[4] := 80; // Год
  sFileName := '';
end;

procedure TfMain.miAddClick(Sender: TObject);
var
  NewStudent: TStudent;
begin
  // 1. Проверяем, задан ли файл (сделаем это в меню «Создать» или «Открыть»)
  if sFileName = '' then
  begin
    ShowMessage('Сначала создайте или откройте файл!');
    Exit;
  end;

  // 2. Читаем данные из полей
  try
    NewStudent.TicketNumber := StrToInt(meTicketNum.Text); // Если в маске цифры
    NewStudent.FullName := edFullName.Text;
    NewStudent.Group := edGroup.Text;
    NewStudent.BirthDate := StrToDate(meBirthDate.Text);
    NewStudent.AdmissionYear := StrToInt(meAdmYear.Text);
  except
    ShowMessage('Ошибка: проверьте правильность заполнения полей!');
    Exit;
  end;

  // 3. Записываем в конец файла
  AssignFile(F, sFileName);
  if FileExists(sFileName) then Reset(F) else Rewrite(F);
  Seek(F, FileSize(F)); // Прыгаем в самый конец файла
  Write(F, NewStudent); // Пишем данные
  CloseFile(F);

  // 4. Обновляем таблицу
  RefreshGrid;
  meTicketNum.Clear;
  edFullName.Clear;
  edGroup.Clear;
  meBirthDate.Clear;
  meAdmYear.Clear;
  edFullName.SetFocus;
end;

procedure TfMain.miClearClick(Sender: TObject);
begin
  meTicketNum.Clear;
  edFullName.Clear;
  edGroup.Clear;
  meBirthDate.Clear;
  meAdmYear.Clear;
  meTicketNum.SetFocus;
end;

procedure TfMain.miDelClick(Sender: TObject);
var
  Stud: TStudent;
  i, CurrentRow: Integer;
begin
  if sgStudents.Row <= 0 then begin ShowMessage('Выберите запись для удаления!'); Exit; end;

  if MessageDlg('Удалить запись?', mtConfirmation, [mbYes, mbNo], 0) = mrNo then Exit;

  CurrentRow := sgStudents.Row - 1;
  AssignFile(F, sFileName);
  Reset(F);

  // Создаем временный файл
  AssignFile(tempF, 'temp.dat'); // Объяви tempF: file of TStudent в private
  Rewrite(tempF);

  i := 0;
  while not Eof(F) do
  begin
    Read(F, Stud);
    if i <> CurrentRow then Write(tempF, Stud); // Копируем всех, кроме удаляемой
    Inc(i);
  end;

  CloseFile(F);
  CloseFile(tempF);

  // Заменяем старый файл новым
  DeleteFile(sFileName);
  RenameFile('temp.dat', sFileName);

  RefreshGrid;
end;

procedure TfMain.miEditClick(Sender: TObject);
var
  Stud: TStudent;
  RowIndex: Integer;
begin
  if sgStudents.Row <= 0 then begin ShowMessage('Выберите запись!'); Exit; end;

  RowIndex := sgStudents.Row - 1; // Номер записи в файле (с нуля)

  // Читаем данные из полей ввода
  Stud.TicketNumber := StrToInt(meTicketNum.Text);
  Stud.FullName := edFullName.Text;
  Stud.Group := edGroup.Text;
  Stud.BirthDate := StrToDate(meBirthDate.Text);
  Stud.AdmissionYear := StrToInt(meAdmYear.Text);

  // Записываем обратно в файл
  AssignFile(F, sFileName);
  Reset(F);
  Seek(F, RowIndex); // Переходим на нужную позицию
  Write(F, Stud);
  CloseFile(F);

  RefreshGrid;
  ShowMessage('Запись обновлена!');
end;

procedure TfMain.miExportTextClick(Sender: TObject);
begin
  ExportToText;
end;

procedure TfMain.miFileClick(Sender: TObject);
begin

end;

procedure TfMain.miHelpClick(Sender: TObject);
begin
  ShowMessage('Инструкция по работе с программой StudBilet:' + #13 +
              '1. ФАЙЛ -> Создать/Открыть: начните работу с выбора базы данных.' + #13 +
              '2. ЗАПИСЬ -> Добавить: заполните поля и добавьте студента.' + #13 +
              '  Напишите в поля для ввода:' + #13 +
                 ' - ФИО студента' + #13 +
                 ' - Группу студента' + #13 +
                 ' - № студбилета в формате цццццц (он должен быть уникальным!)' + #13 +
                 ' - Дату рождения студента в формате дд.мм.гггг' + #13 +
                 ' - Год поступления в учебное учреждение в формате гггг' + #13 +
              '3. Для редактирования/удаления: выберите строку в таблице.' + #13 +
              '4. Сортировка: используйте меню для упорядочивания записей.' + #13 +
              '5. Все данные сохраняются в бинарном файле автоматически.' + #13 +
              '6. Для удобства чтения файла воспользоваться экспортом в текст');
end;

procedure TfMain.miFileExitClick(Sender: TObject);
begin
  Close;
end;

procedure TfMain.miFileNewClick(Sender: TObject);
begin
  if sdMain.Execute then // Открываем диалоговое окно сохранения
  begin
    sFileName := sdMain.FileName; // Запоминаем путь
    // Создаем пустой типизированный файл
    AssignFile(F, sFileName);
    Rewrite(F); // Создает новый файл или перезаписывает существующий
    CloseFile(F);
    // Очищаем таблицу, так как файл теперь пустой
    sgStudents.RowCount := 1;

    ShowMessage('Файл успешно создан: ' + ExtractFileName(sFileName));
  end;
end;

procedure TfMain.miFileOpenClick(Sender: TObject);
begin
  if odMain.Execute then
  begin
    sFileName := odMain.FileName;
    RefreshGrid; // Сразу читаем данные из выбранного файла в таблицу
  end;
end;

procedure TfMain.sgStudentsSelectCell(Sender: TObject; aCol, aRow: Integer;
  var CanSelect: Boolean);
begin
  if aRow > 0 then
  begin
    meTicketNum.Text := sgStudents.Cells[0, aRow];
    edFullName.Text  := sgStudents.Cells[1, aRow];
    edGroup.Text     := sgStudents.Cells[2, aRow];
    meBirthDate.Text := sgStudents.Cells[3, aRow];
    meAdmYear.Text   := sgStudents.Cells[4, aRow];
  end;
end;

procedure TfMain.RefreshGrid;
var
  Stud: TStudent;
  i: Integer;
begin
  sgStudents.RowCount := 1; // Очищаем всё
  if not FileExists(sFileName) then Exit;
  AssignFile(F, sFileName);
  Reset(F);
  i := 1;
  while not Eof(F) do
  begin
    Read(F, Stud);
    sgStudents.RowCount := sgStudents.RowCount + 1;
    sgStudents.Cells[0, i] := IntToStr(Stud.TicketNumber);
    sgStudents.Cells[1, i] := Stud.FullName;
    sgStudents.Cells[2, i] := Stud.Group;
    sgStudents.Cells[3, i] := DateToStr(Stud.BirthDate);
    sgStudents.Cells[4, i] := IntToStr(Stud.AdmissionYear);
    Inc(i);
  end;
  CloseFile(F);
end;
procedure TfMain.ExportToText(FileName: string);
var
  tf: TextFile;
  i: Integer;
begin
  AssignFile(tf, FileName);
  Rewrite(tf);
  // Пишем заголовки
  Writeln(tf, 'Билет;ФИО;Группа;Дата;Год');
  // Пишем данные из таблицы
  for i := 1 to sgStudents.RowCount - 1 do
    Writeln(tf, sgStudents.Cells[0, i] + ';' + sgStudents.Cells[1, i] + ';' +
                sgStudents.Cells[2, i] + ';' + sgStudents.Cells[3, i] + ';' + sgStudents.Cells[4, i]);
  CloseFile(tf);
end;

procedure TfMain.miFileSaveasClick(Sender: TObject);
var
  List: array of TStudent;
  Stud: TStudent;
  i, count: Integer;
begin
  if sdMain.Execute then
  begin
    // 1. Считываем данные из старого файла в память
    if FileExists(sFileName) then
    begin
      AssignFile(F, sFileName);
      Reset(F);
      count := FileSize(F);
      SetLength(List, count);
      for i := 0 to count - 1 do Read(F, List[i]);
      CloseFile(F);
      // 2. Устанавливаем новый путь
      sFileName := sdMain.FileName;
      // 3. Записываем данные в новый файл
      AssignFile(F, sFileName);
      Rewrite(F);
      for i := 0 to count - 1 do Write(F, List[i]);
      CloseFile(F);
      ShowMessage('Файл сохранен как: ' + ExtractFileName(sFileName));
    end
    else
      ShowMessage('Нет данных для сохранения!');
  end;
end;

procedure TfMain.miSearchClick(Sender: TObject);
var
  SearchNum: string;
  i: Integer;
  Found: Boolean;
begin
  SearchNum := InputBox('Поиск', 'Введите номер билета:', '');
  if SearchNum = '' then Exit;

  Found := False;
  for i := 1 to sgStudents.RowCount - 1 do
  begin
    // Сравниваем текст из первого столбца (№ билета)
    if sgStudents.Cells[0, i] = SearchNum then
    begin
      sgStudents.Row := i; // Выделяем найденную строку
      Found := True;
      Break;
    end;
  end;
  if not Found then
    ShowMessage('Студент с таким номером билета не найден!');
end;

procedure TfMain.miSortAscClick(Sender: TObject);
var
  List: array of TStudent;
  Stud: TStudent;
  i, j, count: Integer;
begin
  // 1. Считываем данные в массив
  AssignFile(F, sFileName); Reset(F);
  count := FileSize(F);
  SetLength(List, count);
  for i := 0 to count - 1 do Read(F, List[i]);
  CloseFile(F);

  // 2. Сортировка «пузырьком»
  for i := 0 to count - 2 do
    for j := i + 1 to count - 1 do
      if List[i].TicketNumber > List[j].TicketNumber then
      begin
        Stud := List[i]; List[i] := List[j]; List[j] := Stud;
      end;

  // 3. Записываем обратно
  Rewrite(F);
  for i := 0 to count - 1 do Write(F, List[i]);
  CloseFile(F);
  RefreshGrid;
end;

procedure TfMain.miSortDescClick(Sender: TObject);
var
  List: array of TStudent;
  Stud: TStudent;
  i, j, count: Integer;
begin
  AssignFile(F, sFileName); Reset(F);
  count := FileSize(F);
  SetLength(List, count);
  for i := 0 to count - 1 do Read(F, List[i]);
  CloseFile(F);

  // Сортировка по убыванию
  for i := 0 to count - 2 do
    for j := i + 1 to count - 1 do
      if List[i].TicketNumber < List[j].TicketNumber then // Меняем знак здесь
      begin
        Stud := List[i]; List[i] := List[j]; List[j] := Stud;
      end;

  Rewrite(F);
  for i := 0 to count - 1 do Write(F, List[i]);
  CloseFile(F);
  RefreshGrid;
end;

procedure TfMain.ExportToText;
var
  tf: TextFile;
  i: Integer;
begin
  if sdMain.Execute then
  begin
    AssignFile(tf, sdMain.FileName);
    Rewrite(tf);
    // Пишем заголовки (опционально, но полезно)
    Writeln(tf, 'Билет;ФИО;Группа;Дата;Год');
    // Пишем данные из таблицы
    for i := 1 to sgStudents.RowCount - 1 do
      Writeln(tf, sgStudents.Cells[0, i] + ';' + sgStudents.Cells[1, i] + ';' +
                  sgStudents.Cells[2, i] + ';' + sgStudents.Cells[3, i] + ';' + sgStudents.Cells[4, i]);
    CloseFile(tf);
    ShowMessage('Данные успешно экспортированы в текстовый файл!');
  end;
end;

end.

